WITH top_10_city AS
(SELECT
  loc.City AS city_name,
  SUM(ser.Count) AS no_of_customers,
FROM telecommunication-churn-rate.Telco_customer_churn.Service AS ser
LEFT JOIN telecommunication-churn-rate.Telco_customer_churn.Location AS loc
  ON ser.Customer_ID = loc.Customer_ID
GROUP BY loc.City
ORDER BY no_of_customers DESC
LIMIT 10
)


SELECT
  loc.City AS city_name,
  SUM(CASE WHEN sta.Churn_Label = True THEN ser.COUNT ELSE 0 END) AS churned_customers,
  SUM(CASE WHEN sta.Churn_Label = False THEN ser.COUNT ELSE 0 END) AS not_churned_customers
FROM telecommunication-churn-rate.Telco_customer_churn.Service AS ser
LEFT JOIN telecommunication-churn-rate.Telco_customer_churn.Location AS loc
  ON ser.Customer_ID = loc.Customer_ID
LEFT JOIN telecommunication-churn-rate.Telco_customer_churn.Status AS sta
  ON ser.Customer_ID = sta.Customer_ID
WHERE loc.City IN (SELECT city_name FROM top_10_city)
GROUP BY loc.City



