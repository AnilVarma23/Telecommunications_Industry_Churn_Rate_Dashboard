WITH tenure AS (
SELECT  
  customer_id,
  CASE 
    WHEN Tenure_in_Months > 36 THEN 'Long'
    WHEN Tenure_in_Months > 24 THEN 'Mid'
    ELSE 'New' END AS tenure_category
FROM `telecommunication-churn-rate.Telco_customer_churn.Service`
)

SELECT 
  tenure_category,
  COUNT(customer_id) AS no_of_customers
FROM tenure
GROUP BY tenure_category
ORDER BY COUNT(customer_id) DESC;
