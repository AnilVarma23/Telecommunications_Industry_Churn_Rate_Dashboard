SELECT
    Contract,
    /*convert long data to wide data - Pivot*/
    SUM(CASE WHEN sta.Churn_Label = True THEN ser.Count ELSE 0 END) AS churned_customer, 
    SUM(CASE WHEN sta.Churn_Label = False THEN ser.Count ELSE 0 END) AS not_churned_customer
FROM `telecommunication-churn-rate.Telco_customer_churn.Service` AS ser
LEFT JOIN `telecommunication-churn-rate.Telco_customer_churn.Status` AS sta
ON ser.Customer_ID = sta.Customer_ID
GROUP BY Contract
ORDER BY Contract
