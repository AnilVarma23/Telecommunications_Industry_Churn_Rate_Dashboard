SELECT
  sta.Churn_Label,
  SUM(ser.Count) AS total
FROM
  `telecommunication-churn-rate.Telco_customer_churn.Service` AS ser
LEFT JOIN
  `telecommunication-churn-rate.Telco_customer_churn.Status` AS sta
ON
  ser.Customer_ID = sta.Customer_ID
GROUP BY
  sta.Churn_Label;